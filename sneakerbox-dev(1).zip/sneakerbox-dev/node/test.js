// Import the dependencies for testing
var chai     = require('chai')
const assert   = require('chai').assert
var chaiHttp = require('chai-http');
var app      = require('./app.js');
const UserRepo = require('./Data/UserRepo')
const _userRepo      = new UserRepo();


// Configure chai.
chai.use(chaiHttp);
chai.should();

describe("Users", () => {
    describe("POST /User/RegisterUser", () => {         
        it("Tests values returned by register API are correct", (done) => {
                chai.request(app)
                    .post(`/User/RegisterUser`)
                    .send({'firstName':'John', 'lastName':'Doe', 'email':'jdoe@example.com', 'username':'j_doe7'})
                    .end((err, res) => {
                        res.should.have.status(200);
                        let user = res.body.user
                        console.log("Showing output.");
                        console.log("Response first name:" + user.firstName);
                        console.log("Response last name:" + user.lastName);
                        console.log("Response email:" + user.email);
                        console.log("Response username:" + user.username);
                        user.firstName.should.equal('John')
                        user.lastName.should.equal('Doe')
                        user.email.should.equal('jdoe@example.com')
                        user.username.should.equal('j_doe7')
                        done();
                    });
        });
    });
});


describe("Sell", () => {
    describe("POST /Post/Selling", () => {         
        it("Should have a non-empty error message because of missing required field", (done) => {
                chai.request(app)
                    .post(`/Post/Sell`)
                    .send({'title':'Selling BNIB Jordan 1'})
                    .end((err, res) => {
                        res.should.have.status(200);
                        assert.isNotEmpty(res.body.errorMessage)
                        done();
                    });
        });
    });
});

describe("Buy", () => {
    describe("POST /Post/Buying", () => {         
        it("Should have a non-empty error message because of missing required field", (done) => {
                chai.request(app)
                    .post(`/Post/Buy`)
                    .send({'title':'Buying BNIB Jordan 1'})
                    .end((err, res) => {
                        res.should.have.status(200);
                        assert.isNotEmpty(res.body.errorMessage)
                        done();
                    });
        });
    });
});

describe("Buy", () => {
    describe("POST /Post/Review", () => {         
        it("Should have a non-empty error message because of missing required field", (done) => {
                chai.request(app)
                    .post(`/Post/Buy`)
                    .send({'title':'Buying BNIB Jordan 1'})
                    .end((err, res) => {
                        res.should.have.status(200);
                        assert.isNotEmpty(res.body.errorMessage)
                        done();
                    });
        });
    });
});

