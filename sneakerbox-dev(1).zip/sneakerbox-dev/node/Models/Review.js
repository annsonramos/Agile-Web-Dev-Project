var mongoose         = require('mongoose');

var reviewSchema = mongoose.Schema({
        // title:    {"type": "String", required: true},
        // contact_info:   {"type": "String", require: true},
        // post:    {"type": "String", required: true},
        // price:  {"type": "Number", require: true}


        product_id :{"type": "String", required: true},
        review:     {"type": "String", required: true},
        
},
{ collection : 'review' },
{ versionKey: false }
);
var Review    = mongoose.model('Review', reviewSchema);
module.exports = Review;
