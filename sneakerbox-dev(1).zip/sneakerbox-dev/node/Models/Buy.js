var mongoose         = require('mongoose');

var buySchema = mongoose.Schema({
        title:    {"type": "String", required: true},
        contact_info:   {"type": "String", require: true},
        post:    {"type": "String", required: true},
        price:  {"type": "Number", required: true},
        username: {"type": "String", requred: true}
        
},
{ collection : 'buy' },
{ versionKey: false }
);
var Buy    = mongoose.model('Buy', buySchema);
module.exports = Buy;
