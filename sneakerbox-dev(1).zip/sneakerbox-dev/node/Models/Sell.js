var mongoose         = require('mongoose');

var sellSchema = mongoose.Schema({
        title:    {"type": "String", required: true},
        post:    {"type": "String", required: true},
        price:   {"type":  Number, required: true},
        username: {"type": "String", requred: true}
},
{ collection : 'sell' },
{ versionKey: false }
);
var Sell    = mongoose.model('Sell', sellSchema);
module.exports = Sell;
