const BuyRepo   = require('../Data/BuyRepo');
const _buyRepo  = new BuyRepo();
const Buy       = require('../Models/Buy');

// This is the default page for domain.com/product/index.
// It shows a listing of products if any exist.
exports.Index = async function(request, response){
    let buys = await _buyRepo.allBuys();
    if(buys!= null) {
        response.json({ buys:buys })
    }
    else {
        response.json( { buys:[] })
    }
};

// Shows one single object at a time. 
exports.Detail = async function(request, response) {
    // request.query used to get url parameter.
    let productID  = request.query._id; 
    
    let productObj = await _buyRepo.getBuy(productID);
    response.json( { product:productObj });
}

// GET request calls here to display 'Product' create form.
exports.Create = async function(request, response) {
    response.json( { errorMessage:"", product:{} });
};

// Receives POST data and tries to save it.
exports.CreateBuy = async function(request, response) {

    // Package object up nicely using content from 'body'
    // of the POST request.
    let tempBuyObj  = new Buy( {
        "_id":request.body._id,
        "title":    request.body.title,
        "contact_info": request.body.contact_info,
        "post":        request.body.post,
        "price":    request.body.price,
        "username": request.body.username
    });

    // Call Repo to save 'Product' object.
    let responseObject = await _buyRepo.create(tempBuyObj);

    // No errors so save is successful.
    if(responseObject.errorMessage == "") {
        console.log('Saved without errors.');
        console.log(JSON.stringify(responseObject.obj));
        response.json({ buy:responseObject.obj,
                                            errorMessage:""});
    }
    // There are errors. Show form the again with an error message.
    else {
        console.log("An error occured. Item not created.");
        response.json( {
                        buy:responseObject.obj,
                        errorMessage:responseObject.errorMessage});
    }
};

exports.Delete = async function(request, response) {
    let id           = request.body._id;
    let buy     = await _buyRepo.allBuys();
    let deleteitem   = await _buyRepo.delete(id);
    response.json({buy:buy});
}

