const SellRepo   = require('../Data/SellRepo');
const _sellrepo  = new SellRepo();
const Sell       = require('../Models/Sell');

// This is the default page for domain.com/product/index.
// It shows a listing of products if any exist.
exports.Index = async function(request, response){
    let sells = await _sellrepo.allSells();
    if(sells!= null) {
        response.json({ sells:sells })
    }
    else {
        response.json( { sells:[] })
    }
};

// Shows one single object at a time. 
exports.Detail = async function(request, response) {
    // request.query used to get url parameter.
    let sellID  = request.query._id; 
    
    let sellObj = await _sellrepo.getSell(sellID);
    response.json( { sell:sellObj });
}

// GET request calls here to display 'Product' create form.
exports.Create = async function(request, response) {
    response.json( { errorMessage:"", product:{} });
};

// Receives POST data and tries to save it.
exports.CreateSell = async function(request, response) {

    let tempSellObj  = new Sell( {
        "_id":request.body._id,
        "title":    request.body.title,
        "post":        request.body.post,
        "price":    request.body.price,
        "username": request.body.username
    });

    let responseObject = await _sellrepo.create(tempSellObj);

    // No errors so save is successful.
    if(responseObject.errorMessage == "") {
        console.log('Saved without errors.');
        console.log(JSON.stringify(responseObject.obj));
        response.json({ sell:responseObject.obj,
                                            errorMessage:""});
    }
    // There are errors. Show form the again with an error message.
    else {
        console.log("An error occured. Item not created.");
        response.json( {
                        sell:responseObject.obj,
                        errorMessage:responseObject.errorMessage});
    }
};

exports.Delete = async function(request, response) {
    let id           = request.body._id;
    let sell     = await _sellrepo.allSells();
    let deleteitem   = await _sellrepo.delete(id);
    response.json({sell:sell});
}