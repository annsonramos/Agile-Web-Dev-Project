const Review = require('../Models/Review');

class ReviewRepo {
    
    // This is the constructor.
    ReviewRepo() {        
    }

    // Gets all products.
    async allReviews() {     
        let reviews = await Review.find().exec();
        return   reviews;
    }

    async getReview(id) {  
        let review = await Review.findOne({_id:id}).exec();
        return   review;
    }

    async create(reviewObj) {
        try {
            // Checks if model conforms to validation rules that we set in Mongoose.
            var error = await reviewObj.validateSync();
    
            // The model is invalid. Return the object and error message. 
            if(error) {
                let response = {
                    obj:          reviewObj,
                    errorMessage: error.message };
    
                return response; // Exit if the model is invalid.
            } 
    
            // Model is not invalid so save it.
            const result = await reviewObj.save();
    
            // Success! Return the model and no error message needed.
            let response = {
                obj:          result,
                errorMessage: "" };
    
            return response;
        } 
        //  Error occurred during the save(). Return orginal model and error message.
        catch (err) {
            let response = {
                obj:          reviewObj,
                errorMessage: err.message };
    
            return  response;
        }    
    } 
}


module.exports = ReviewRepo;
