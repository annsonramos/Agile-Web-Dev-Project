
var HomeController   = require('./Controllers/HomeController');
var UserController   = require('./Controllers/UserController');
var SellController   = require('./Controllers/SellController');
var BuyController   = require('./Controllers/BuyController');   
var ReviewController   = require('./Controllers/ReviewController'); 
const authMiddleware = require('./authHelper')
const cors           = require('cors');


// Routes
module.exports = function(app){  
    // Main Routes
    app.get('/',      HomeController.Index);

    app.get('/User/Register', cors(), UserController.Register);
    app.post('/User/RegisterUser', cors(), UserController.RegisterUser);
    app.get('/User/Login', cors(), UserController.Login);
    app.post('/User/LoginUser', cors(), UserController.LoginUser);
    app.get('/User/Logout', cors(), UserController.Logout);
    app.get('/Post/Index', cors(), SellController.Index);
    app.get('/Post/Detail', cors(), SellController.Detail);
    app.post('/Post/Sell', cors(), SellController.CreateSell);
    app.get('/Buy/Index', cors(), BuyController.Index);
    app.get('/Buy/Detail', cors(), BuyController.Detail);
    app.post('/Post/Buy', cors(), BuyController.CreateBuy);





    // app.get('/User/SecureArea', cors(), UserController.SecureArea);
    // app.get('/User/ManagerArea', cors(), UserController.ManagerArea);
    // Sign in
    app.post(
        '/auth', cors(),
        // middleware that handles the sign in process
        authMiddleware.signIn,
        authMiddleware.signJWTForUser
    )

// Accessible to authenticated user. CORS must be enabled
// for client App to access it.
    app.get('/User/SecureAreaJwt', cors(),
        authMiddleware.requireJWT, UserController.SecureAreaJwt)

// Accessible to manager or admin. CORS must be enabled for
// client App to access it.
    app.get('/User/ManagerAreaJwt', cors(),
        authMiddleware.requireJWT, UserController.ManagerAreaJwt)

// Receives posted data from authenticated users.
    app.post('/User/PostAreaJwt', cors(),
        authMiddleware.requireJWT, UserController.PostAreaJwt)

    app.get('/Sell/Index', cors(), SellController.Index)



// reviews stuff.
    // app.post('/Review/Index', cors(), ReviewController.Index)
    app.post('/Post/Review', cors(), ReviewController.CreateReview);
    app.get('/Review/Index', cors(), ReviewController.Index);

    app.delete('/Sell/Delete', cors(), SellController.Delete)
    app.delete('/Buy/Delete', cors(), BuyController.Delete)


};
