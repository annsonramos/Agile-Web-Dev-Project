import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

const BASE_URL = 'http://localhost:1337/User/RegisterUser';

@Component({
  template: `
  <section class=" bg2">
  <div class="register fadeInDown">
  <div class="row justify-content-center">
                      <div class="col-md-7">
                          <div class="card myCard">
                              <div class="card-header">Account Registration</div>
                              <div class="card-body">
                                  <form class="form-horizontal" action="/User/RegisterUser" method="POST" action="#">
                                      <div class="form-group">
                                          <div class="cols-sm-10">
                                              <div class="input-group">
                                                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                                                  <input type="text" class="form-control fadeIn first rounded" name="firstname" 
                                                  [(ngModel)]="_firstName" id="name" placeholder="First Name" />
                                              </div>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="cols-sm-10">
                                              <div class="input-group">
                                                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                                                  <input type="text" class="form-control fadeIn second rounded" name="lastname" id="name" [(ngModel)]="_lastName" placeholder="Last Name" />
                                              </div>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                         
                                          <div class="cols-sm-10">
                                              <div class="input-group">
                                                  <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                                                  <input type="text" class="form-control fadeIn third rounded" name="email" id="email" [(ngModel)]="_email" placeholder="Email" />
                                              </div>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="cols-sm-10">
                                              <div class="input-group">
                                                  <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
                                                  <input type="text" class="form-control fadeIn fourth rounded" name="username" id="username" [(ngModel)]="_username" placeholder="Username" />
                                              </div>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                        
                                          <div class="cols-sm-10">
                                              <div class="input-group">
                                                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                                  <input type="password" class="form-control fadeIn fifth rounded" name="password" id="password" [(ngModel)]="_password" placeholder="Password" />
                                              </div>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                         
                                          <div class="cols-sm-10">
                                              <div class="input-group">
                                                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                                  <input type="password" class="form-control fadeIn sixth rounded" name="confirm" id="confirm" [(ngModel)]="_passwordConfirm" placeholder="Confirm your Password" />
                                              </div>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <button type="button" class="btn btn-primary btn-lg btn-block login-button fadeIn seventh rounded-circle" (click)="registerUser()">Register</button>
                                      </div>
                                      <div class="cols-sm-5">
                                        <div class="input-group">
                                        <p class="text-white fadeIn eigth">Already have an account?<a routerLink="/login" routerLinkActive="active"> Login</a><p>
                                        </div>
                                    </div>
                                  </form>
                              </div>
  
                          </div>
                      </div>
                  </div>
  </div>
  {{this._errorMessage}}
  </section>
<br/>
  `
})


export class PageBComponent {
  _http:HttpClient;
  _username: String;
  _email:String;
  _password: String;
  _passwordConfirm: String;
  _firstName: String;
  _lastName: String;
  _errorMessage:String = "";

  constructor(private http: HttpClient, public router: Router) {
    this._http = http;
  }
  
registerUser() {
  // This free online service receives post submissions.
  this.http.post(BASE_URL,
    {
      firstName:        this._firstName,
      lastName:         this._lastName,
      email:            this._email,
      username:         this._username,
      password:         this._password,
      passwordConfirm:  this._passwordConfirm
    })
    .subscribe(
      // Data is received from the post request.
      (data) => {
        // Inspect the data to know how to parse it.
        console.log("POST call successful. Inspect response.",
          JSON.stringify(data));
        this._errorMessage = data["errorMessage"];
        // this.router.navigate(['./main'])

      },
      // An error occurred. Data is not received.
      error => {
        this.router.navigate(['./main'])
      });
}

}
