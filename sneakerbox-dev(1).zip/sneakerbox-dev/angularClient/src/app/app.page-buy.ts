import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';


const BASE_URL = "http://localhost:1337/Post/";

@Component({
    template: `
    <div>
    <div class="home-wrap">
        <div class="home-inner text-center">
        </div>
    </div>
    <div class="BuySellPage">
    <div class="row fadeIn">
       <div class="col-4 TextAreas">
       <h1 class="BuySellHeader">Add Buy Listing</h1>
       <b>Title: </b><br>
       <input class="posts" type="text"   [(ngModel)]="_title" /> <br>
<!--    <b>Contact Information: </b><br>
       <textarea class="posts" [(ngModel)]="_contact_info" rows="2" cols="30">
       </textarea><br> -->
       <b>Post: </b><br>
       <textarea class="posts" [(ngModel)]="_post" rows="4" cols="50">
       </textarea><br>
       <b>Price: </b><br>
       <input class="posts" type="text"   [(ngModel)]="_price" /> <br>   
       <br/>
       <input class="posts" type="submit" value="Add Item" (click)="createPost()">
       </div>
    </div>
    </div>
</div>

    {{_errorMessage}}`
})
export class PageBuyComponent {
    _productsArray: Array<any>;
    _http:HttpClient;
    _title:String;
    _post: String;
    _editableProductName:String="";
    _errorMessage:String = "";
    _editId:Number = null;
    _singleProductNumber : number = null;
    _singleProductName: string = "";
    _price:number;
    _contact_info: String;

    // Since we are using a provider above we can receive
    // an instance through a constructor.
    constructor(private http: HttpClient, public router: Router) {
        this._http = http;
        this.getAllProducts();
        console.log(this._errorMessage)
    }

    getAllProducts() {
      let url = BASE_URL + 'Index'
      this._http.get<any>(url)
          // Get data and wait for result.
          .subscribe(result => {
              this._productsArray = result.products;
          },

          error =>{
            // Let user know about the error.
              this._errorMessage = error;
          })
    }

    getProduct(id) {
        let url = BASE_URL + 'Detail?_id=' + id;

        this._http.get<any>(url)
            // Get data and wait for result.
            .subscribe(result => {
                this._singleProductName = result.product.productName;
                this._singleProductNumber = result.product._id;
            },

            error =>{
              // Let user know about the error.
                this._errorMessage = error;
            })
      }

      createPost() {
        // This free online service receives post submissions.
        this.http.post(BASE_URL + "Buy",
            {
                title:   this._title,
                contact_info: this._contact_info,
                post:  this._post,
                price: this._price,
                username: sessionStorage.getItem("user")
            })
        .subscribe(
            // Data is received from the post request.
            (data) => {
                // Inspect the data to know how to parse it.
                console.log("POST call successful. Inspect response.",
                            JSON.stringify(data));
                this._errorMessage = data["errorMessage"];
                this.getAllProducts();
                if (this._errorMessage == "") {
                    this.router.navigate(['./main'])
                }
            },
            // An error occurred. Data is not received.
            error => {
                this._errorMessage = error;
            });
    }

    deleteProduct(_id) {

      const httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
        "body": { _id:_id}
      };

      let url = BASE_URL + "Delete"
      this.http.delete(  url , httpOptions)
      .subscribe(
          // Data is received from the post request.
          (data) => {
              this._errorMessage = data["errorMessage"];
              this.getAllProducts();
          },
          // An error occurred. Data is not received.
          error  => {
            this._errorMessage = error;
          });
    }

    updateProduct() {
        // This free online service receives post submissions.
        this.http.put(BASE_URL + "Update",
            {
                _id:         this._editId,
                productName: this._editableProductName,
            })
        .subscribe(
            // Data is received from the post request.
            (data) => {
                // Inspect the data to know how to parse it.
                console.log("PUT call successful. Inspect response.",
                            JSON.stringify(data));
                this._errorMessage = data["errorMessage"];
                this.getAllProducts();
            },
            // An error occurred. Data is not received.
            error => {
                this._errorMessage = error;
            });
    }
}
