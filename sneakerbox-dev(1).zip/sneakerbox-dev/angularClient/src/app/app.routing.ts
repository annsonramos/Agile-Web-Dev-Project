import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule }  from '@angular/router';
import { AppComponent }          from './app.component';
import { PageAComponent }        from './app.main';
import { PageBComponent }        from './app.register';
import { PageCComponent }        from './app.login';
import { PageBuyComponent }      from './app.page-buy';
import { PageSellComponent}      from './app.page-sell';
import { SellPostsComponent }    from './app.view-sellposts';
import { BuyPostsComponent }     from './app.view-buyposts'
import { UserPostsComponent }    from './app.user';
import { from } from 'rxjs';

const appRoutes: Routes = [
    { path: 'main', component: PageAComponent },
    { path: 'register', component: PageBComponent },
    { path: 'login', component: PageCComponent },
    { path: 'page-buy', component: PageBuyComponent},
    { path: 'page-sell', component: PageSellComponent},
    { path: 'selling/:_id', component: SellPostsComponent},
    { path: 'buying/:_id', component: BuyPostsComponent},
    { path: 'user', component: UserPostsComponent},
    { path: '', redirectTo: '/main', pathMatch: 'full' }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
