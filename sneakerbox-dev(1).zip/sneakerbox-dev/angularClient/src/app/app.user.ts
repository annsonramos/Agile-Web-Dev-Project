import { Component, OnInit } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import { ActivatedRoute } from '@angular/router';
import { AuthService } from './AuthService'


@Component({
    styles: ['* {font-family: Arial, sans-serif; font-size:1em} table { border-collapse: collapse; width: 80%; table-layout: fixed; border: 2px solid black;}'],
  providers: [AuthService],
  template: `
  <body data-spy="scroll" data-target="navbarResponsive">
  <br><br><br>
  <div class="jumbotron">
  <div class="narrow jumbotron buy-sell">
      <div class= "row text-center">
      <div class="col-12 text-center">
      <h3 class="heading">Here are your postings!</h3>
      <div class="heading-underline2"></div>
      </div>
          <div class="col-md-6">
              <h3 class="subHeading">What you're looking for</h3>
              <div class="items table-wrapper-scroll-y my-custom-scrollbar">
               
              <table class="buyTable table table-bordered table-striped mb-0" style="width:325px; border: 1px solid black">
              <tr>
              <!--  <td>
                  <b>post</b>
              </td>
      
              <!-- <td>
                  <b>price</b>
              </td>-->
              </tr>
      
              <tr *ngFor="let post of _productsArray2.slice(0,5)">
              <div *ngIf="_username === post.username">
      
              <td>
                  <a class="titles" [routerLink]="['/buying', post._id]">{{post.title}}</a>
              </td>
              <td>
                  <input type="submit" value="Delete" (click)="deleteBuy(post._id)">
              </td>
              </div>
              </tr>
              </table>
              </div>
          
          </div>
          <div class="col-md-6">
              <h3 class="subHeading">What you're selling</h3>
              <div class="items table-wrapper-scroll-y my-custom-scrollbar">

              <table class="sellTable table table-bordered table-striped mb-0" style="width:325px; border: 1px solid black">
              <tr>
                  <!--  <td>
                      <b>post</b>
                  </td>
                  <td>
                      <b>price</b>
                  </td>-->
                  </tr>
                  <tr *ngFor="let product of _productsArray.slice(0,5)">
                  <div *ngIf="_username === product.username">
                  <td>
                  <a class="titles" [routerLink]="['/selling', product._id]">{{product.title}}
                  </a>
                  </td>
                  <!--   <td>
                  {{product.post}}
                  </td>
                  <td>
                  {{product.price}}
                  </td>-->
                  <td>
                      <input type="submit" value="Delete" (click)="deleteSell(product._id)">
                  </td>
                  </div>
                  </tr>
              </table>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="contact">

<footer>
<div class="row justify-content-center">
  <div class="col-md-5 text-center">
  <a class="navbar-brand"><img src="Sneakerbox.png"></a>
      <p>Here in our community we strive to keep our customers feel satisfied
      when using our website. If you have any concerns or issues, don't hesitate to contact us.</p>
      <strong>Contact Info</strong>
      <p>(778) 999-9999<br>sneakerbox@yahoo.com</p>
  </div>
</div>
</footer>

</div>
</body>

  
  `
})

export class UserPostsComponent  {
    _http:HttpClient;
    _errorMessage:String = "";
    _productsArray: Array<any>
    _productsArray2: Array<any>
    _username: String
  
  constructor(private http: HttpClient, AuthService: AuthService) {
    this._http = http;
    // this.loggedOn = AuthService.isLoggedOn()
    this.getAllProducts();
    this.getAllProducts2();
  }

  getAllProducts() {
    let url = "http://localhost:1337/Sell/Index"
    this._http.get<any>(url)
        .subscribe(result => {
            this._productsArray = result.sells.reverse();
            this._username = sessionStorage.getItem("user")
        }, 

        error =>{
            this._errorMessage = error;
        })
  }

  getAllProducts2() {
      let url = "http://localhost:1337/Buy/Index"
      this._http.get<any>(url)
          .subscribe(result => {
              this._productsArray2 = result.buys.reverse();
          }, 

          error =>{
              this._errorMessage = error;
          })
          console.log(this._productsArray2)
    }

    deleteSell(_id) {

        const httpOptions = {
          headers: new HttpHeaders({ 'Content-Type': 'application/json' }), 
          "body": { _id:_id}
        };
      
        let url = "http://localhost:1337/Sell/Delete"
        this.http.delete(  url , httpOptions) 
        .subscribe(
            // Data is received from the post request.
            (data) => {
                this._errorMessage = data["errorMessage"];
                this.getAllProducts(); 
            },
            // An error occurred. Data is not received. 
            error  => {
              this._errorMessage = error; 
            });
            console.log(this._productsArray)
      }

      deleteBuy(_id) {

        const httpOptions = {
          headers: new HttpHeaders({ 'Content-Type': 'application/json' }), 
          "body": { _id:_id}
        };
      
        let url = "http://localhost:1337/Buy/Delete"
        this.http.delete(  url , httpOptions) 
        .subscribe(
            // Data is received from the post request.
            (data) => {
                this._errorMessage = data["errorMessage"];
                this.getAllProducts2(); 
            },
            // An error occurred. Data is not received. 
            error  => {
              this._errorMessage = error; 
            });
            console.log(this._productsArray2)
      }
}

