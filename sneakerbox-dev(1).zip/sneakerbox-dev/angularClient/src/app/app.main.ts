import { Component } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import { AuthService } from './AuthService'

const BASE_URL = "http://localhost:1337/Sell/Index";

@Component({
    styles: ['* {font-family: Arial, sans-serif; font-size:1em} table { border-collapse: collapse; width: 80%; table-layout: fixed; border: 2px solid black;}'],
    providers: [AuthService],
    template:`
    <body data-spy="scroll" data-target="navbarResponsive">
    <div>
        <div class="home-wrap">
            <div class="home-inner text-center">
            </div>
        </div>
        <div class="caption text-center">
            <h1>Welcome to Sneakerbox</h1>
            <h2>Where amazing deals happen!</h2>
        </div>
    </div>
    <div class="jumbotron aboutUs offset">
        <div class="col-12 jumbotron narrow text-center">
          <h3 class="heading">About Us</h3>
          <p class="lead">We provide a marketplace for sneakerheads to post items for sale or for buy.
          Users are able to post an item for buy or for sale, we give these users a place for them to find or sell
          the best shoes of this era. If you don't have an account yet, come join us now!</p>
          <a class="btn btn-secondary btn-md" routerLink="/register" routerLinkActive="active">Join the hype now!</a>
        </div>
    </div>

    <div class="jumbotron">
        <div class="narrow">
            <div class="col-12 text-center">
            <h3 class="heading">Buy/Sell Lists</h3>
            <div class="heading-underline"></div>
            </div>
            <div class= "row text-center">
                <div class="col-md-6">
                    <div class="items">
                    <p><i class="fas fa-shopping-cart cart" data-fa-transform="grow-20"></i></p>
                    <h3 class="subHeading">Buy List</h3> 
                    <p class="info">Buyers can post items they're looking for to
                    attract potential sellers</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="items">
                    <p><i class="fas fa-dollar-sign dollar" data-fa-transform="grow-20"></i><p>
                    <h3 class="subHeading">Sell List</h3>
                    <p class="info">Sellers can post items they're selling to attract
                    potential buyers</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="rules-section">
        <div class="dark">
        <div class="caption2 text-center">
            <p class="exclamation"><i class="fas fa-exclamation-triangle" data-fa-transform="grow-20"></i></p>
            <h3 class="heading">Rules</h3>
            <p>A strict reminder to everyone that we do not tolerate flakers, low-ballers, and any other unprofessional behaviours from buyers and sellers.
            We try to keep our community safe and sound to have a peaceful marketplace for the most popular shoes up to date.</p>
        </div>
        </div>
    </div>

    <div class="jumbotron">
        <div class="narrow jumbotron buy-sell">
            <div class= "row text-center">
            <div class="col-12 text-center">
            <h3 class="heading">Find what you're looking for here!</h3>
            <div class="heading-underline2"></div>
            </div>
                <div class="col-md-6">
                    <h3 class="subHeading">For Buy</h3>
                    <div class="items table-wrapper-scroll-y my-custom-scrollbar">
                     
                    <table class="buyTable table table-bordered table-striped mb-0" style="width:325px; border: 1px solid black">
                    <tr>
                    <!--  <td>
                        <b>post</b>
                    </td>
            
                    <!-- <td>
                        <b>price</b>
                    </td>-->
                    </tr>
            
                    <tr *ngFor="let post of _productsArray2.slice(0,5)">
            
                    <td>
                        <a class="titles" [routerLink]="['/buying', post._id]">{{post.title}}</a>
                    </td>
                    </tr>
                    </table>
                    </div>
                
                </div>
                <div class="col-md-6">
                    <h3 class="subHeading">For Sale</h3>
                    <div class="items table-wrapper-scroll-y my-custom-scrollbar">

                    <table class="sellTable table table-bordered table-striped mb-0" style="width:325px; border: 1px solid black">
                    <tr>
                        <!--  <td>
                            <b>post</b>
                        </td>
                        <td>
                            <b>price</b>
                        </td>-->
                        </tr>
                        <tr *ngFor="let product of _productsArray.slice(0,5)">
                        <td>
                        <a class="titles" [routerLink]="['/selling', product._id]">{{product.title}}
                        </a>
                        </td>
                        <!--   <td>
                        {{product.post}}
                        </td>
                        <td>
                        {{product.price}}
                        </td>-->
                        </tr>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contact">

    <footer>
    <div class="row justify-content-center">
        <div class="col-md-5 text-center">
        <a class="navbar-brand"><img src="Sneakerbox.png"></a>
            <p>Here in our community we strive to keep our customers feel satisfied
            when using our website. If you have any concerns or issues, don't hesitate to contact us.</p>
            <strong>Contact Info</strong>
            <p>(778) 999-9999<br>sneakerbox@yahoo.com</p>
        </div>
    </div>
    </footer>

    </div>
    </body>
    `
    

})

// <div class="offset sellSection">

//     <div class="col-12 narrow text-center">
//         <h1 class="text-light sellTitle" id="sell">Items for sale</h1>
        // <table class="sellTable h-100 align-items-center">

        // <tr>
        //     <td>
        //         <b>Title</b>
        //     </td>
        //     <!--  <td>
        //         <b>post</b>
        //     </td>
        //     <td>
        //         <b>price</b>
        //     </td>-->
        // </tr>
        // <tr *ngFor="let product of _productsArray.slice(0,5)">
        // <td>
        //     <a [routerLink]="['/selling', product._id]">{{product.title}}
        //     </a>
        // </td>
        // <!--   <td>
        //     {{product.post}}
        // </td>

        // <td>
        //     {{product.price}}
        // </td>-->
        // </table>
        
    //     </div>
    // </div>
//     <div id="buy" class="offset buySection">

//     <div class="col-12 narrow text-center">
        // <h1 class="text-light buyTitle">Items for buy</h1>
        // <table class="buyTable">

        // <tr>
        // <td>
        //     <b>Title</b>
        // </td>

        // <!--  <td>
        //     <b>post</b>
        // </td>

        // <td>
        //     <b>price</b>
        // </td>-->
        // </tr>

        // <tr *ngFor="let post of _productsArray2.slice(0,5)">

        // <td>
        //     <a [routerLink]="['/buying', post._id]">{{post.title}}</a>
        // </td>
        // </table>
        
//         </div>
//     </div>

// <table style="background-color: #ffffff; border:2px black solid;">

// <col width="200">
// <col width="100">
// <col width="125">

// <tr>
//     <td>
//         <b>Title</b>
//     </td>

//     <!--  <td>
//         <b>post</b>
//     </td>

//     <td>
//         <b>price</b>
//     </td>-->
// </tr>


// <tr *ngFor="let product of _productsArray.slice(0,5)">

// <td>
//     <a [routerLink]="['/selling', product._id]">{{product.title}}
//     </a>
// </td>

// <!--   <td>
//     {{product.post}}
// </td>

// <td>
//     {{product.price}}
// </td>-->

// </table>

// <table style="background-color: #ffffff; border:2px black solid;">

// <col width="200">
// <col width="100">
// <col width="125">

// <tr>
//     <td>
//         <b>Title</b>
//     </td>

//     <!--  <td>
//         <b>post</b>
//     </td>

//     <td>
//         <b>price</b>
//     </td>-->
// </tr>

// <tr *ngFor="let post of _productsArray2.slice(0,5)">

// <td>
//     <a [routerLink]="['/buying', post._id]">{{post.title}}
//     </a>
// </td>


// </table>

export class PageAComponent { 

    _http:HttpClient;
    _errorMessage:String = "";
    _productsArray: Array<any>
    _productsArray2: Array<any>
  
    // Since we are using a provider above we can receive
    // an instance through a constructor.
    constructor(private http: HttpClient, AuthService: AuthService) {
      this._http = http;
      // this.loggedOn = AuthService.isLoggedOn()
      this.getAllProducts();
      this.getAllProducts2();
    }

    getAllProducts() {
      let url = BASE_URL
      this._http.get<any>(url)
          .subscribe(result => {
              this._productsArray = result.sells.reverse();
          }, 

          error =>{
              this._errorMessage = error;
          })
    }

    getAllProducts2() {
        let url = "http://localhost:1337/Buy/Index"
        this._http.get<any>(url)
            .subscribe(result => {
                this._productsArray2 = result.buys.reverse();
            }, 

            error =>{
                this._errorMessage = error;
            })
            console.log(this._productsArray2)
      }

      deleteSell(_id) {

        const httpOptions = {
          headers: new HttpHeaders({ 'Content-Type': 'application/json' }), 
          "body": { _id:_id}
        };
      
        let url = "http://localhost:1337/Sell/Delete"
        this.http.delete(  url , httpOptions) 
        .subscribe(
            // Data is received from the post request.
            (data) => {
                this._errorMessage = data["errorMessage"];
                this.getAllProducts(); 
            },
            // An error occurred. Data is not received. 
            error  => {
              this._errorMessage = error; 
            });
            console.log(this._productsArray)
      }

      deleteBuy(_id) {

        const httpOptions = {
          headers: new HttpHeaders({ 'Content-Type': 'application/json' }), 
          "body": { _id:_id}
        };
      
        let url = "http://localhost:1337/Buy/Delete"
        this.http.delete(  url , httpOptions) 
        .subscribe(
            // Data is received from the post request.
            (data) => {
                this._errorMessage = data["errorMessage"];
                this.getAllProducts2(); 
            },
            // An error occurred. Data is not received. 
            error  => {
              this._errorMessage = error; 
            });
            console.log(this._productsArray2)
      }

}
