import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    template:   
     `
      {{updateLinks()}}
    <body data-spy="scroll" data-target="navbarResponsive">
    <ng-template [ngIf]="roles.includes('nonUser')">
    <nav class="navbar navbar-expand-md navbar-dark py-1 nav-bg fixed-top">
    <a class="navbar-brand"><img src="Sneakerbox.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
      <span class="navbar-toggler-icon navbar-light"></span>
    </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
           <li class="nav-item"><a class="nav-link" routerLink="/main" routerLinkActive="active"><i class="fas fa-fw fa-home home"></i>Home</a></li>
           <li class="nav-item"><a class="nav-link" routerLink="/register" routerLinkActive="active"><i class="fas fa-registered register"></i>Register</a></li>
           <li class="nav-item"><a class="nav-link" routerLink="/login" routerLinkActive="active"><i class="fas fa-sign-in-alt sign-in"></i>Login</a></li>
        </ul>
      </div>
    </nav></ng-template>

    <ng-template [ngIf]="roles.includes('Admin') || roles.includes('Manager') || roles.length == 0 ">
    <nav class="navbar navbar-expand-md navbar-dark py-1 nav-bg fixed-top">
    <a class="navbar-brand"><img src="Sneakerbox.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
      <span class="navbar-toggler-icon navbar-light"></span>
    </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" routerLink="/main" routerLinkActive="active"><i class="fas fa-fw fa-home home"></i>Home</a></li>
            <li class="nav-item"><a class="nav-link" routerLink="/page-buy" routerLinkActive="active"><i class="fas fa-cart-plus buy"></i>Buy</a></li>
            <li class="nav-item"><a  class="nav-link "routerLink="/page-sell" routerLinkActive="active"><i class="fas fa-dollar-sign sell"></i>Sell</a></li>
            <li class="nav-item"><a class="nav-link" routerLink="/user" routerLinkActive="active"><i class="fas fa-thumbtack"></i>Your Postings</a></li>
            <li class="nav-item"><a  class="nav-link "href=# (click)='logout()'><i class="fas fa-sign-out-alt sign-out"></i>Logout[{{username}}]</a></li>
        </ul>
      </div>
        </nav></ng-template>
    </body>


    <!-- Where router should display a view -->
    <router-outlet></router-outlet>`
})
export class AppComponent { 
  timestamp:string = "";
  // Create an empty array.
  roles:Array<any> = [];
  username: string;
  loggedOn: boolean
  loggedOnAdmin: boolean

  constructor() {
  }


logout() {
    sessionStorage.clear();
}


updateLinks() {
    let ROLE_KEY = "roles";
    
    // Create some fake data if roles are not cached in the browser.
    if(sessionStorage.getItem(ROLE_KEY)==null) {
        // Here is some fake data.
        let roleObject = ['nonUser'];

        // The roles returned from Node.js would be stored with 
        // the following line of code inside login.ts.
        sessionStorage.setItem(ROLE_KEY, JSON.stringify(roleObject));
    }
    else {
        // Read roles from the cache and store in an array.
    this.roles = JSON.parse(sessionStorage.getItem(ROLE_KEY))

    }

    if(sessionStorage.getItem("user") != null) {
        this.username = sessionStorage.getItem("user")
    }

}
} 
