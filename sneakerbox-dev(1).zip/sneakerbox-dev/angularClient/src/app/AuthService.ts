import { Component } from '@angular/core';

// This is the service.
export class AuthService {
    loggedOn: boolean
    loggedOnAdmin: boolean

    isLoggedOn() {
        // Logged in if token exists in browser cache.
        if(sessionStorage.getItem('auth_token')!=null) {
            return true
        }
        else {
            return false
        }
    }
    
    isAdmin() {
        if(sessionStorage.getItem('roles').includes('Admin')) {
            return true
        }
        else {
            return false
        }
    }
}
