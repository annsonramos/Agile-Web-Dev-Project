import { Component  } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ApiService } from './ApiService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  template: `
  <section class="bg">
  <section class="row">
     <section class="col-12 col-sm-6 col-md-3">
          <div class="form-container fadeInDown">
              <div class="form-group">
              <p class="account-login">Account Login<p>
                  <input type="text" class="form-control fadeIn first" id="_username" aria-describedby="emailHelp" placeholder="Username" [(ngModel)]='username'/><br/>
              </div>
              <div class="form-group">
                  <input type="password" class="form-control fadeIn second" id="_password" placeholder="Password" [(ngModel)]='password'/><br/>
              </div>
          <input type='button' class="btn btn-primary btn-block fadeIn third rounded-circle" value='login' (click)='login()'/>
          <p class="text-white no account fadeIn fourth">Don't have an account?<a routerLink="/register" routerLinkActive="active"> Register</a><p>
      </div>
    </section>
  </section>
  </section>
`

})


// Login name: <input type='text' [(ngModel)]='username'/><br/>
// Password:   <input type='text' [(ngModel)]='password'/><br/>
// <input type='button' value='login' (click)='login()'/>`


export class PageCComponent {
    // Hard-code credentials for convenience.
    password              = '';         
    username              = '';
    
    token                 = '';
    message               = 'Not logged in.';
    secureData:string     = '';
    managerData:string    = '';
    reqInfo:any           = {};
    msgFromServer:string  = '';
    _apiService:ApiService;
    public site='http://localhost:1337/';

    // Since we are using a provider above we can receive 
    // an instance through an constructor.
    constructor(private http: HttpClient, public router: Router) {
        // Pass in http module and pointer to AppComponent.
        this._apiService = new ApiService(http, this);

    }
  


    //------------------------------------------------------------
    // Log user in. 
    //------------------------------------------------------------
    login() {
        let url = this.site + "auth";
    
        // This free online service receives post submissions.
        this.http.post(url, {
                username:  this.username,
                password:  this.password,
            })
        .subscribe( 
        // Data is received from the post request.
        (data) => {
            // Inspect the data to know how to parse it.
            console.log(JSON.stringify(data));
            
            if(data["token"]  != null)  {
                this.token = data["token"]     
                sessionStorage.setItem('auth_token', data["token"]);
                sessionStorage.setItem('roles', JSON.stringify(data["user"]["roles"]));
                sessionStorage.setItem('user', data["user"]["username"] )
                this.message = "The user has been logged in."  
            }    
            this.router.navigate(['./main'])
        },
        // An error occurred. Data is not received. 
        error => {
            alert(JSON.stringify(error));
        });
    }

    //------------------------------------------------------------
    // Log user out. Destroy token.
    //------------------------------------------------------------
    logout() {
        sessionStorage.clear();

        // Clear data.
        this.secureData    = ""; 
        this.managerData   = "";
        this.reqInfo       = {};
        this.msgFromServer = "";
    }
}
