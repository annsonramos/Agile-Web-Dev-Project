import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule }      from '@angular/forms';
import { AppComponent } from './app.component';
import { PageAComponent } from './app.main';
import { PageBComponent } from './app.register';
import { PageCComponent } from './app.login';
import { PageBuyComponent }      from './app.page-buy';
import { PageSellComponent}      from './app.page-sell';
import { SellPostsComponent }    from './app.view-sellposts';
import { BuyPostsComponent }    from './app.view-buyposts';
import { UserPostsComponent }   from './app.user';
import { routing }        from './app.routing';

@NgModule({
  declarations: [
    AppComponent,
    PageAComponent, 
    PageBComponent,
    PageCComponent,
    PageBuyComponent,
    PageSellComponent,
    SellPostsComponent,
    BuyPostsComponent,
    UserPostsComponent
  ],
  imports: [
    BrowserModule, HttpClientModule, FormsModule, routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
