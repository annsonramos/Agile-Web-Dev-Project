
import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from './AuthService';
import { Router } from '@angular/router';


const BASE_URL = 'http://localhost:1337/Post/Detail?_id=';
const REVIEW_URL = "http://localhost:1337/Post/";


@Component({
  providers: [AuthService],
  template: `
  <div class= "reviewPage-container">
    <div class="view-wrap">
      <div class="view-inner">
      </div>
    </div>
  <div class="reviewPage fadeIn">
    <div class="reviewTitles">
          <div class="reviewHeadings">
            <h1>Title: {{_singleTitle}}</h1>
            <h2>Post: {{_singlePost}}</h2>
            <h2>Price: $\{{_singlePrice}}</h2>
          </div>
      <h1>Leave a review</h1>
    </div>

    <textarea [(ngModel)]="_review" rows="4" cols="50">
    </textarea><br><br>
    <input type="submit" value="Submit Review" (click)="createReview()">
    <h3 class="reviews"> Reviews: </h3>
    <div class="reviews-wrapper jumbotron">

    <table class="viewTable table table-boredered table-sm table-wrapper-scroll-y my-custom-scrollbar" style="width:400px">

    <tr *ngFor="let post of _reviewsArray">
  

    <td class="reviewPosts" *ngIf="post.product_id == sellID">
        {{post.review}}
    </td>



    </table>
    </div>
    </div>


  `
})

export class SellPostsComponent implements OnInit {
  sellID: string;
  _singleTitle:String = "wow";
  _singlePost:String;
  _singlePrice: Number;
  _errorMessage:String = "";
  _reviewsArray: Array<any>;
  _review:String;


  constructor(private _http: HttpClient, private route: ActivatedRoute, AuthService:AuthService, public router: Router) {
        this.getAllReviews();
        this.ngOnInit();
        console.log(this._errorMessage)
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.sellID = params['_id']  
    });
    this.getProduct(this.sellID)       
  }

  getProduct(id) {
    let url = BASE_URL + id;

    this._http.get<any>(url)
        // Get data and wait for result.
        .subscribe(result => {
            this._singleTitle = result.sell.title;
            this._singlePost = result.sell.post;
            this._singlePrice = result.sell.price
        },

        error =>{
          // Let user know about the error.
            this._errorMessage = error;
        })
  }

  createReview() {
    // This free online service receives post submissions.
    this._http.post(REVIEW_URL + 'review',
        {
            // title:   this._singleTitle,
            // // contact_info: this._contact_info,
            // post:  this._singlePost,
            // price: this._singlePrice,
            product_id: this.sellID,
            review: this._review
        })
    .subscribe(
        // Data is received from the post request.
        (data) => {
            // Inspect the data to know how to parse it.
            console.log("POST call successful. Inspect response.",
                        JSON.stringify(data));
            this._errorMessage = data["errorMessage"];
            this.getProduct(this.sellID);
            if (this._errorMessage == "") {
                this.router.navigate(['./main'])
            }
        },
        // An error occurred. Data is not received.
        error => {
            this._errorMessage = error;
        });
}


  getAllReviews() {
    let url = "http://localhost:1337/Review/Index"
    this._http.get<any>(url)
        .subscribe(result => {
            this._reviewsArray = result.reviews.reverse();
        }, 
  
        error =>{
            this._errorMessage = error;
        })
        console.log(this._reviewsArray)
  }
}

