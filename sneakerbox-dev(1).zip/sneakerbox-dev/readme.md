# Sneakerbox

Sneakerbox is an enthusiast-focused classified - ads website for athletic/style/work shoes.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

What things you need to install the software and how to install them

```
Node.js
MongoDB
Angular
```

### Installing

Run `npm install` in both the angularClient and node folders




